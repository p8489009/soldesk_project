import boto3
import csv
import json
from datetime import datetime
from io import StringIO

dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')

# DynamoDB 테이블 이름
table_name = 'SurveyResponses'
# S3 버킷 이름
s3_bucket_name = 'aws-dynamodb-surveyresponses-item'

def lambda_handler(event, context):
    table = dynamodb.Table(table_name)
    response = table.scan()
    items = response['Items']

    # 현재 날짜와 시간을 기준으로 경로 설정
    now = datetime.now()
    year = now.strftime('%Y')
    month = now.strftime('%m')
    day = now.strftime('%d')
    hour = now.strftime('%H')
    minute = now.strftime('%M')
    
    s3_key_csv = f"AWSItems/533267020503/DynamodbItems/ap-northeast-2/Surveys/{year}/{month}/{day}/{hour}/{minute}/data.csv"

    # CSV 파일로 저장
    csv_buffer = StringIO()
    csv_writer = csv.writer(csv_buffer)

    # CSV 헤더 작성
    headers = ["SurveyId", "Timestamp", "ResponseId"]
    max_questions = 0
    for item in items:
        responses = item.get("Responses", [])
        max_questions = max(max_questions, len(responses))

    for i in range(1, max_questions + 1):
        headers.append(f"Question{i}")
        headers.append(f"Answer{i}")

    csv_writer.writerow(headers)

    # CSV 데이터 작성
    for item in items:
        row = [item["SurveyId"], item["Timestamp"], item["ResponseId"]]
        responses = item.get("Responses", [])
        for response in responses:
            row.append(response['question'])
            row.append(response['answer'])
        
        # 만약 질문/답변 수가 최대 질문 수보다 적다면 빈 필드 추가
        while len(row) < len(headers):
            row.append("")
            
        csv_writer.writerow(row)

    s3.put_object(
        Bucket=s3_bucket_name,
        Key=s3_key_csv,
        Body=csv_buffer.getvalue()
    )

    return {
        'statusCode': 200,
        'body': json.dumps('DynamoDB items have been saved to S3 in CSV format')
    }
