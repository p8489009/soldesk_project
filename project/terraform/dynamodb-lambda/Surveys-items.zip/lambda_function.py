import boto3
import csv
import json
from datetime import datetime
from io import StringIO

dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')

# DynamoDB 테이블 이름
table_name = 'Surveys'
# S3 버킷 이름
s3_bucket_name = 'aws-dynamodb-surveys-item'

def lambda_handler(event, context):
    table = dynamodb.Table(table_name)
    response = table.scan()
    items = response['Items']

    # 현재 날짜와 시간을 기준으로 경로 설정
    now = datetime.now()
    year = now.strftime('%Y')
    month = now.strftime('%m')
    day = now.strftime('%d')
    hour = now.strftime('%H')
    minute = now.strftime('%M')
    
    s3_key_csv = f"AWSItems/533267020503/DynamodbItems/ap-northeast-2/Surveys/{year}/{month}/{day}/{hour}/{minute}/data.csv"

    # CSV 파일로 저장
    csv_buffer = StringIO()
    csv_writer = csv.writer(csv_buffer)

    # CSV 헤더 작성
    if items:
        # 기본 헤더 작성
        headers = list(items[0].keys())
        headers.remove('Questions')  # Questions 필드는 나중에 추가
        max_questions_length = max(len(item.get('Questions', [])) for item in items)
        max_choices_length = max(len(q['choices']) for item in items for q in item.get('Questions', []))

        question_headers = [f"QuestionText_{i+1}" for i in range(max_questions_length)]
        choice_headers = [f"Choices_{i+1}-{j+1}" for i in range(max_questions_length) for j in range(max_choices_length)]
        
        # 새로운 헤더 순서에 맞게 조정
        header_row = headers + sum([[f"QuestionText_{i+1}"] + [f"Choices_{i+1}-{j+1}" for j in range(max_choices_length)] for i in range(max_questions_length)], [])
        
        csv_writer.writerow(header_row)

        # CSV 데이터 작성
        for item in items:
            row = [item.get(header, '') for header in headers]
            questions = item.get('Questions', [])
            for i in range(max_questions_length):
                if i < len(questions):
                    question = questions[i]
                    row.append(question.get('questionText', ''))
                    row.extend(question['choices'] + [''] * (max_choices_length - len(question['choices'])))
                else:
                    row.append('')
                    row.extend([''] * max_choices_length)
            csv_writer.writerow(row)

    s3.put_object(
        Bucket=s3_bucket_name,
        Key=s3_key_csv,
        Body=csv_buffer.getvalue()
    )

    return {
        'statusCode': 200,
        'body': json.dumps('DynamoDB items have been saved to S3 in CSV format')
    }
